package com.oop.java;

public class Balloon {
	private String color;
	public Balloon(){
}
	public Balloon(String c){
		this.color=c;
	}	
	public String getColor(){
		return color;
	}
	public void setColor(String color){
		this.color = color;
	}


}
