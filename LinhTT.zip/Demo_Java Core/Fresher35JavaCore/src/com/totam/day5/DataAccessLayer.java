package com.totam.day5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DataAccessLayer {
	Connection sqlConnect = null;
	Statement stmt = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	ArrayList<Students> ds;
	
	public Connection getConnect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			sqlConnect = DriverManager.getConnection("jdbc:sqlserver://CPP00082816A\\" +
					"TAMTTT3:1433;databaseName=StudentDB; username=sd;" +
					" password=Hoaphuc123#");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqlConnect;
	}
	
	public void addNewStudents(Students stud){
		String sql = "insert into Students values('"+stud.getId()+"','"+stud.getName()+"','"+stud.getAddress()+"',"+stud.getAge()+")";
		try {
			stmt = getConnect().createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public ArrayList<Students> listStudent(String n, int a){
		String sql ="select * from Students where Name =? and Age =? ";
		try {
			pstmt = getConnect().prepareStatement(sql);
			pstmt.setString(1, n);
			pstmt.setInt(2, a);
			rs = pstmt.executeQuery();
			Students stu;
			ds = new ArrayList<Students>();
			while(rs.next()){
				stu = new Students();
				stu.setId(rs.getString("Id"));
				stu.setName(rs.getString("Name"));
				stu.setAddress(rs.getString("Address"));
				stu.setAge(rs.getInt("Age"));
				ds.add(stu);			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ds;
	}
	
	public static void main(String[] args) {
		DataAccessLayer db = new DataAccessLayer();
		Scanner input = new Scanner(System.in);
		//System.out.println("Enter ID");
		//String id = input.nextLine();
		System.out.println("enter name");
		String name = input.nextLine();
		//System.out.println("enter address");
		//String add = input.nextLine();
		System.out.println("enter age");
		int age = input.nextInt();
		
		//create instance of Students
		//Students stu1 = new Students(id, name, add, age);
		
		//add new students
		//db.addNewStudents(stu1);
		//search student with name and age
		ArrayList<Students> dssv = new ArrayList<Students>();
		 dssv = db.listStudent(name,age);
		for (Students item : dssv) {
			System.out.println(item.toString());
			//System.out.println(students.getAge());
		}
	}

}

