package com.totam.day2;

public class Person {
	private float wid;
	
	

	/**
	 * @param wid
	 */
	public Person(float wid) {
		//super();
		this.wid = wid;
	}

	public Person() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the wid
	 */
	public float getWid() {
		return wid;
	}

	/**
	 * @param wid the wid to set
	 */
	public void setWid(float wid) {
		this.wid = wid;
	}
	

}
