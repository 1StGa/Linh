import java.util.Date;
import java.util.Scanner;

public class StudentManagement {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Nhap vao ten");
		String tenSinhVien = input.nextLine();

		System.out.println("Nhap Ngay Sinh");
		// valid
		String ngay = input.nextLine();
		Date ngaySinhSV = new Date(ngay);
		System.out.println("Nhap Dia Chi");
		String diaChi = input.nextLine();

		// Students st1 = new Students(tenSinhVien, ngaySinhSV, diaChi);
		Students st1 = new Students();
		st1.huy();
		//Students st2 = new Students(tenSV, ngaySinh, diaChi)

	}

}
