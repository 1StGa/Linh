import java.util.Date;

public class Students {
	private String tenSV;
	private Date ngaySinh;
	private String diaChi;
	static String abc;

	public Students(String tenSV, Date ngaySinh, String diaChi) {
		super();
		this.tenSV = tenSV;
		this.ngaySinh = ngaySinh;
		this.diaChi = diaChi;
		//
	}

	public Students() {
//
	}
	
	public Students(String tenSV){
		
	}
	public void huy(){
		try {
			this.finalize();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			System.out.println("Khong huy duoc");
			e.printStackTrace();
		}
	}

	public String getTenSV() {
		return tenSV;
	}

	
	public Date getNgaySinh() {
		return ngaySinh;
	}

	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}

	public String getDiaChi() {
		return diaChi;
	}

	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}

	@Override
	public String toString(){
		return "HoTen"+this.getTenSV();
	}
}
