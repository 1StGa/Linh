package com.totam.day2.interfac;

public interface CanDrink {
	public static final String NUOC_LOC ="Nuoc Loc";
	public static final String NUOC_KHOANG = "Nuoc Khoang";
	
	public void drink();

}
