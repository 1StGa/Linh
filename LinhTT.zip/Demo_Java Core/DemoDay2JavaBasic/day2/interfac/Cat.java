package com.totam.day2.interfac;

public class Cat extends Animal implements CanEat, CanDrink{

	@Override
	public void drink() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int spead() {
		// TODO Auto-generated method stub
		return 0;
	}

}
