package com.totam.day2.interfac;

public interface CanMove {
	public static final String phuongTien ="Chan";
	public void run();
	

}
