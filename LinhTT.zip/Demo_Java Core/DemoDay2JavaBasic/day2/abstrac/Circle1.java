package com.totam.day2.abstrac;

public class Circle1 extends Circle{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("draw circle1");
		
	}

	@Override
	public String getNew() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
