package com.totam.day2.abstrac;

public abstract class Shape {
	private String tenShape;
	
	public Shape(){
		//this.tenShape = "Hinh dang";
		System.out.println("da duoc khoi tao");
	}

	public String getTenShape() {
		return tenShape;
	}

	public void setTenShape(String tenShape) {
		this.tenShape = tenShape;
	}
	
	public abstract void draw();
	public void show(){
		System.out.println("hien thi duoi dang 2DS");
	}
	public abstract String nameShape();
	
	

}
