package com.oop.java;
import java.util.Date;


public abstract class BaoHiem {
	
	private String tenGoiBH;
	private float tgDong;
	private float mucPhiDong;
	private String mucDich;
	private String cachThucDong;
	private Date tgBatDau;
	
	public BaoHiem(){
		
	}
	
	public BaoHiem(String tenGoiBH, float tgDong, float mucPhiDong,
			String mucDich, String cachThucDong, Date tgBatDau) {
		super();
		this.tenGoiBH = tenGoiBH;
		this.tgDong = tgDong;
		this.mucPhiDong = mucPhiDong;
		this.mucDich = mucDich;
		this.cachThucDong = cachThucDong;
		this.tgBatDau = tgBatDau;
	}
	/**
	 * get ten goi bao hiem
	 * @return tenGoiBH
	 */
	public String getTenGoiBH() {
		return tenGoiBH;
	}
	
	/**
	 * set ten goi bao hiem
	 * @param tenGoiBH
	 */
	public void setTenGoiBH(String tenGoiBH) {
		this.tenGoiBH = tenGoiBH;
	}
	
	/**
	 * get thoi gian dong
	 * @return tgDong
	 */
	public float getTgDong() {
		return tgDong;
	}
	
	/**
	 * set thoi gian dong
	 * @param tgDong
	 */
	public void setTgDong(float tgDong) {
		this.tgDong = tgDong;
	}
	
	/**
	 * get muc phi dong
	 * @return mucPhiDong
	 */
	public float getMucPhiDong() {
		return mucPhiDong;
	}
	
	/**
	 * set muc phi dong
	 * @param mucPhiDong
	 */
	public void setMucPhiDong(float mucPhiDong) {
		this.mucPhiDong = mucPhiDong;
	}
	
	/**
	 * get muc dich
	 * @return mucDich
	 */
	public String getMucDich() {
		return mucDich;
	}
	
	/**
	 * set muc dic
	 * @param mucDich
	 */
	public void setMucDich(String mucDich) {
		this.mucDich = mucDich;
	}
	
	/**
	 * get cach thuc dong
	 * @return cachThucDong
	 */
	public String getCachThucDong() {
		return cachThucDong;
	}
	
	/**
	 * set cach thuc dong
	 * @param cachThucDong
	 */
	public void setCachThucDong(String cachThucDong) {
		this.cachThucDong = cachThucDong;
	}
	
	/**
	 * get thoi gian bat dau
	 * @return tgBatDau
	 */
	public Date gettgBatDau() {
		return tgBatDau;
	}
	
	/**
	 * set thoi gian
	 * @param tgBatDau
	 */
	public void settgBatDau(Date tgBatDau) {
		this.tgBatDau = tgBatDau;
	}

}
