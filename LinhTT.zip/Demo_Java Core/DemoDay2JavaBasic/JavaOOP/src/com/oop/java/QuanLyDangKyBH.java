package com.oop.java;
import java.util.Date;
import java.util.Scanner;


public class QuanLyDangKyBH {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		//Khoi tao 1 loai bao hiem theo thoi han hop dong
		BaoHiem bh = new BaoHiemHopDong(new Date("20/8/2010"), "abc");
		bh.setCachThucDong("6 thang mot lan");
		bh.setMucDich("nuoi con");
		bh.setMucPhiDong(300000);
		bh.settgBatDau(new Date("01/01/2016"));
		bh.setTenGoiBH("BH hop dong");
		bh.setTgDong(3);
		KhachHang kh = new KhachHang("TamTTT3", new Date("07/01/1980"), "Da Nang", "321456987", bh);
		
		//in thong tin da nhap
		System.out.println(kh.getBaoHiem().getCachThucDong());
	}

}
