package LinhTT.Day23;

import java.util.Date;
import java.util.Scanner;

public class Experience extends Candidate {
	private int expInYear;
	private String proSkill;
	
	public Experience(String candidateId, String fullName, Date birthDay,
			String phone, String email, int expInYear, String proSkill) {
		super(candidateId, fullName, birthDay, phone, email);
		this.expInYear = expInYear;
		this.proSkill = proSkill;
	}


	public int getExpInYear() {
		return expInYear;
	}


	public void setExpInYear(int expInYear) {
		this.expInYear = expInYear;
	}


	public String getProSkill() {
		return proSkill;
	}


	public void setProSkill(String proSkill) {
		this.proSkill = proSkill;
	}


	public Experience() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public void inputInfo() {
		Scanner sc = new Scanner(System.in);
		super.inputInfo();
		System.out.println("int put expinyear : ");
		setExpInYear(sc.nextInt());
		System.out.println(" in put proskill : ");
		sc = new Scanner(System.in);
		setProSkill(sc.nextLine());
	}


	public void showInfo(Candidate candidate) {
		// TODO Auto-generated method stub
		super.showInfo();
		
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
