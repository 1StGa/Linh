package LinhTT.Day23;

import java.util.Date;
import java.util.Scanner;


public class Candidate {
	private String candidateId;
	private String fullName;
	private Date birthDay;
	private String phone;
	private String email;
	public String getCandidateId() {
		return candidateId;
	}
	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public Date getBirthDay() {
		return birthDay;
	}
	public void setBirthDay(Date birthDay) {
		this.birthDay = birthDay;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Candidate(String candidateId, String fullName, Date birthDay,
			String phone, String email) {
		super();
		this.candidateId = candidateId;
		this.fullName = fullName;
		this.birthDay = birthDay;
		this.phone = phone;
		this.email = email;
	}
	public Candidate() {
		
		
	}
public void inputInfo(){
	Scanner sc = new Scanner(System.in);
	System.out.print("in put candidateId :  ");
	sc = new Scanner(System.in);
	setCandidateId(sc.nextLine());
	System.out.print("in put fullName :  ");
	sc = new Scanner(System.in);
	setFullName(sc.nextLine());
	System.out.print("in put birthDay : ");
	sc = new Scanner(System.in);
	String date = sc.nextLine();
	Date birthDay = new Date(date);
	System.out.print("in put phone : ");
	setPhone(sc.next());
	System.out.print("in put email : ");
	sc = new Scanner(System.in);
	setEmail(sc.nextLine());
	
		
	}
	
	public void showInfo(){
		System.out.println("CandidateId : "+this.candidateId);
		System.out.println("FullName : "+this.fullName);
		System.out.println("BirthDay : "+this.birthDay);
		System.out.println("Phone : "+this.phone);
		System.out.println("Email : "+this.email);
		
	}
	public static void main(String[] args) {
		Candidate ca = new Candidate();
		ca.inputInfo();
		ca.showInfo();

	}
}

