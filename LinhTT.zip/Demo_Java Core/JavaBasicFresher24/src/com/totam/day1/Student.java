package com.totam.day1;

import java.sql.Connection;

public class Student {
	// khoi tao cac bien SQL
	public Connection con = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int x, y;
	int a=5, b=6;
	x = 5* ++b;
	System.out.println("x="+x);
	int c=6;
	y=5 * c++;
	System.out.println("y="+y);
	System.out.println("c="+c);

	}

	/**
	 * in danh sach sinh vien
	 * 
	 * @param x
	 *            , y ThrowException SQLException, IOException
	 */
	public void getStudentList() {
		// statement
		for(int i=0; i<=10; i++){
			System.out.println(i);
		}
		
	}

}
