package com.totam.day2;

import java.util.Date;

public class SinhVien {
	private String tenSV;
	private int canNangSV;
	private String diaChiThuongTru;
	private Date ngaySinh;
	
	public SinhVien(){
		
	}

	public SinhVien(String tenSV, int canNangSV, String diaChiThuongTru) {
		super();
		this.tenSV = tenSV;
		this.canNangSV = canNangSV;
		this.diaChiThuongTru = diaChiThuongTru;
	}

	public String getTenSV() {
		return tenSV;
	}

	public void setTenSV(String tenSV) {
		this.tenSV = tenSV;
	}

	public int getCanNangSV() {
		return canNangSV;
	}

	public void setCanNangSV(int canNangSV) {
		this.canNangSV = canNangSV;
	}

	public String getDiaChiThuongTru() {
		return diaChiThuongTru;
	}

	public void setDiaChiThuongTru(String diaChiThuongTru) {
		this.diaChiThuongTru = diaChiThuongTru;
	}

	public Date getNgaySinh() {
		return ngaySinh;
	}

	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	@Override
	public String toString(){
		return "ten sinh vien"+this.getTenSV()+"\ncan nang"+this.getCanNangSV()+"\nngay sinh"+this.getNgaySinh();
	}
	
	//pu

}
