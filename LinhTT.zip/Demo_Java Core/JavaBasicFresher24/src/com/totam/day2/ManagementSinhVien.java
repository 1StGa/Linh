package com.totam.day2;

import java.util.Date;
import java.util.Scanner;

public class ManagementSinhVien {
	public static void main(String[] args) {
		SinhVien sv1 = new SinhVien();
		Scanner input = new Scanner(System.in);
		
		// Nhap thong tin sinh vien
		System.out.println("Nhap ten sinh vien");
		String tenSinhVien = input.nextLine();
		sv1.setTenSV(tenSinhVien);
		System.out.println("Nhap can nang sinh vien");
		int canNang = input.nextInt();
		sv1.setCanNangSV(canNang);
		System.out.println("Nhap vao dia chi sinh vien");
		String diaChi = input.nextLine();
		System.out.println("Nhap ngay sinh");
		String ngaySinh= input.nextLine();
		Date ns = new Date(ngaySinh);
		sv1.setNgaySinh(ns);
		
		System.out.println("thong tin sinh vien la\n"+sv1.toString());
		
		
		//SinhVien sv2 = new SinhVien(tenSinhVien,34,"DN");
		
	}

}
