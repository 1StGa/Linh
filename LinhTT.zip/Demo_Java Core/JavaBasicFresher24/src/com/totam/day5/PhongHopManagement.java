package com.totam.day5;

import java.util.ArrayList;
import java.util.Scanner;

public class PhongHopManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	/*	Scanner input = new Scanner(System.in);
	System.out.println("Nhap ten phong");
	String tenPhong = input.nextLine();
	
	System.out.println("Nhap so ghe");
	int soGhe = input.nextInt();
	
	Scanner input1 = new Scanner(System.in);
	System.out.println("nhap vi tri");
	String vitri = input1.nextLine();

	PhongHop ph1 = new PhongHop(tenPhong, soGhe, vitri);
	
	DataAccess db = new DataAccess();
	db.addnewPhongHop(ph1);*/
		DataAccess db = new DataAccess();
		
		ArrayList<PhongHop> listPhong = db.getListPhongHop();
		for (PhongHop phongHop : listPhong) {
			System.out.println(phongHop.toString());
		}
	}

}
