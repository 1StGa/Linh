package com.tam.day5;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class AccessDB {
	Connection sqlConnect = null;
	Statement stmt = null;
	PreparedStatement pstmt = null;
	CallableStatement callStmt = null;
	ResultSet rs = null;
	ArrayList<SinhVien> dssv;

	/**
	 * connect to database
	 */
	public Connection getConnect() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			sqlConnect = DriverManager
					.getConnection("jdbc:sqlserver://CPP00082816A\\"
							+ "TAMTTT3:1433;databaseName=QLSINHVIEN; username=sd;"
							+ " password=Hoaphuc123!");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return sqlConnect;

	}

	public void themMoiSinhVien(SinhVien sv) {

		// dinh dang ngay sinh
		SimpleDateFormat dinhdangngay = new SimpleDateFormat("yyyy-MM-dd");
		String ngaysinh = dinhdangngay.format(sv.getNgaySinh());
		java.sql.Date nssql = java.sql.Date.valueOf(ngaysinh);
		String sql = "insert into SinhVien values('" + sv.getMaSinhVien()
				+ "','" + sv.getTenSinhVien() + "','" + nssql + "','"
				+ sv.getDiaChi() + "')";
		try {
			stmt = getConnect().createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void themMoiSinhVienUsePre(SinhVien sv) {

		// dinh dang ngay sinh
		SimpleDateFormat dinhdangngay = new SimpleDateFormat("yyyy-MM-dd");
		String ngaysinh = dinhdangngay.format(sv.getNgaySinh());
		java.sql.Date nssql = java.sql.Date.valueOf(ngaysinh);

		String sql = "insert into SinhVien values(?,?,?,?)";

		try {
			pstmt = getConnect().prepareStatement(sql);
			// sinh vien 1
			pstmt.setString(1, "009");
			pstmt.setString(2, "lan");
			pstmt.setDate(3, nssql);
			pstmt.setString(4, "quang nam");
			// sinh vien 2
			pstmt.setString(1, "019");
			pstmt.setString(2, "lan");
			pstmt.setDate(3, nssql);
			pstmt.setString(4, "quang nam");

			// sinh vien 3

			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public ArrayList<SinhVien> danhSachSinhVien(String diaChi) {
		try {
			callStmt = getConnect().prepareCall("{call sp_getSinhVienNS(?)}");
			callStmt.setString(1, diaChi);
			getConnect().setAutoCommit(false);
			rs = callStmt.executeQuery();
			SinhVien sv;
			dssv = new ArrayList<SinhVien>();
			while (rs.next()) {
				String masv = rs.getString("MaSV");
				String tensv = rs.getString("TenSV");
				// dinh dang ngay sinh
				SimpleDateFormat dinhdangNS = new SimpleDateFormat("yyyy-MM-dd");
				String ngaysinh = dinhdangNS.format(new java.util.Date(rs
						.getDate("NgaySinh").getDate()));
				java.sql.Date ngaysinhhienthi = java.sql.Date.valueOf(ngaysinh);

				String diachi = rs.getString("DiaChi");

				sv = new SinhVien(masv, tensv, ngaysinhhienthi, diachi);
				dssv.add(sv);
			getConnect().commit();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			getConnect().rollback();
		}
		return dssv;

	}

}
