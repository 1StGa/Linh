package com.tam.day5;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class QuanLySinhVien {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		//nhap thong tin sinh vien
		/*System.out.println("Nhap ma sinh vien");
		String maSV = input.nextLine();
		System.out.println("Nhap ten sinh vien");
		String tenSV = input.nextLine();
		System.out.println("Nhap ngay sinh sinh vien");
		String ngaysinh = input.nextLine();
		Date ns = new Date(ngaysinh);*/
		System.out.println("Dia chi");
		String diachi = input.nextLine();
		
		//tao doi tuong sinh vien
		//SinhVien sv = new SinhVien(maSV, tenSV, ns, diachi);
		AccessDB db = new AccessDB();
		//db.themMoiSinhVien(sv);
		ArrayList<SinhVien> ds = db.danhSachSinhVien(diachi);
		for (SinhVien sinhVien : ds) {
			System.out.println(sinhVien.toString());
			
		}
	}

}
